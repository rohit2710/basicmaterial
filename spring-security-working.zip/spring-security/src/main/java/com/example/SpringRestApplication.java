package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.http.HttpMethod;
import org.springframework.http.RequestEntity;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.example.security.User;
import com.example.security.UserRepository;


@SpringBootApplication(scanBasePackages = "com.example")
@EnableJpaRepositories
public class SpringRestApplication implements CommandLineRunner{

	public static void main(String[] args) {
		SpringApplication.run(SpringRestApplication.class, args);
	}

	@Autowired
	UserRepository ur;
	@Override
	public void run(String... args) throws Exception {
		
		ur.save(new User("user", new BCryptPasswordEncoder().encode("user"), true, "ROLE_USER"));
		ur.save(new User("admin", new BCryptPasswordEncoder().encode("admin"), true, "ROLE_ADMIN"));
	}
}
