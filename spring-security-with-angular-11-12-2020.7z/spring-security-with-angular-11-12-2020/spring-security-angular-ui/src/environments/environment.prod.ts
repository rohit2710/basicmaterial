export const environment = {
  production: true,
  baseURL: 'http://localhost:8082'
};
